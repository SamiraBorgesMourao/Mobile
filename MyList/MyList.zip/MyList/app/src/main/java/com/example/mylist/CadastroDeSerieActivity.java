package com.example.mylist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CadastroDeSerieActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_de_serie);
    }
}